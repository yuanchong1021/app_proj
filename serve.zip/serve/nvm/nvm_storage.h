/**
 * @file    nvm_storage.h
 * @brief   非易失存储服务（NVM Storage）
 *
 * 该模块在 HAL_NVM 之上做一层"业务地址 + 数据校验"的封装：
 *   - 集中管理 NVM 内的地址布局（不让业务模块直接写裸地址）
 *   - 通过 magic 字节判断首次上电、防止读取未初始化数据
 *   - 屏蔽 EEPROM / 模拟 EEPROM Flash 的差异
 *
 * 当前仅提供里程持久化接口（odo_km / trip_dm）。
 */

#ifndef CLUSTER_NVM_STORAGE_H
#define CLUSTER_NVM_STORAGE_H

#include "cluster_context.h"

/**
 * @brief 从 NVM 读取里程数据到 sys->lcd.odometer
 *
 * @param sys  系统上下文
 *
 * 行为：
 *   - 若 magic 字节不匹配（说明 NVM 未初始化），将 odo_km / trip_dm 重置为 0
 *   - 否则按 little-endian 还原 32 位 odo_km 与 16 位 trip_dm
 */
void NVM_LoadOdometer(ClusterSystem_t *sys);

/**
 * @brief 把当前里程数据写入 NVM
 *
 * @param sys  系统上下文（只读取 sys->lcd.odometer）
 *
 * 写入顺序：先写数据再写 magic，提升掉电安全性。
 */
void NVM_SaveOdometer(const ClusterSystem_t *sys);

#endif /* CLUSTER_NVM_STORAGE_H */
