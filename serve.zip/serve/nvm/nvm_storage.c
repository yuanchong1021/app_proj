/**
 * @file  nvm_storage.c
 * @brief NVM 存储服务（里程持久化）
 */
#include "nvm_storage.h"
#include "hal_nvm.h"

/*
 * RAM 仿真 NVM 布局（由 hal_nvm.c 管理）：
 *   offset 0   : magic  (由 HAL 内部维护，0xA5=有效)
 *   offset 1   : 预留
 *   offset 2~5 : ODO  (u32 LE)
 *   offset 6~7 : TRIP (u16 LE)
 */
#define NVM_OFF_ODO   4u
#define NVM_OFF_TRIP  8u

void NVM_LoadOdometer(ClusterSystem_t *sys)
{
    u8 buf[4];
    if (!HAL_NVM_Read(NVM_OFF_ODO, buf, 4u)) {
        sys->lcd.odometer.odo_km  = 0u;
        sys->lcd.odometer.trip_dm = 0u;
        return;
    }
    sys->lcd.odometer.odo_km =
        ((u32)buf[0])        |
        ((u32)buf[1] <<  8u) |
        ((u32)buf[2] << 16u) |
        ((u32)buf[3] << 24u);

    if (!HAL_NVM_Read(NVM_OFF_TRIP, buf, 2u)) {
        sys->lcd.odometer.trip_dm = 0u;
        return;
    }
    sys->lcd.odometer.trip_dm = (u16)buf[0] | ((u16)buf[1] << 8u);
}

void NVM_SaveOdometer(const ClusterSystem_t *sys)
{
    u8  buf[4];
    u32 odo  = sys->lcd.odometer.odo_km;
    u16 trip = sys->lcd.odometer.trip_dm;

    buf[0] = (u8)( odo        & 0xFFu);
    buf[1] = (u8)((odo >>  8u) & 0xFFu);
    buf[2] = (u8)((odo >> 16u) & 0xFFu);
    buf[3] = (u8)((odo >> 24u) & 0xFFu);
    HAL_NVM_Write(NVM_OFF_ODO, buf, 4u);

    buf[0] = (u8)( trip       & 0xFFu);
    buf[1] = (u8)((trip >> 8u) & 0xFFu);
    HAL_NVM_Write(NVM_OFF_TRIP, buf, 2u);
}
