/**
 * @file    boot_app_if.h
 * @brief   Boot 与 App 之间的接口契约
 *
 * ★ 本文件内容必须与 Bootloader 工程中的同名文件逐字节一致 ★
 *   本项目（App）与 Bootloader 是两个独立的 IAR 工程/仓库，没有共用目录，
 *   因此这里是"手工同步"的一份拷贝，而不是同一份源码的相对路径引用。
 *   里面定义的地址、结构体、魔数一旦两边不一致，表现是刷写能完成但
 *   Boot 永远不跳 App，且没有任何编译错误、没有任何日志——非常难查。
 *   建议：每次改动本文件后，在 Boot 工程里做一次逐字比对（diff）。
 *
 * ── Flash 分区 ──────────────────────────────────────────────────────────
 *   0x00000000 ─ 0x000003FF   Boot 中断向量表      1KB
 *   0x00000400 ─ 0x00007FFF   Boot 代码            31KB
 *   0x00008000 ─ 0x000083FF   App  中断向量表      1KB
 *   0x00008400 ─ 0x0000846F   App  信息块          112B
 *   0x00008470 ─ 0x0003FFFF   App  代码            ~223KB
 *   0x10001000 ─ 0x100037FF   数据 Flash（刷写记录，仅 Boot 读写）
 *
 * ── SRAM 分区 ───────────────────────────────────────────────────────────
 *   0x20000000 ─ 0x200003FF   运行时中断向量表副本
 *   0x20000400 ─ 0x20007BFF   .data / .bss / .code_ram
 *   0x20007C00 ─ 0x20007FF7   栈（1016 字节）
 *   0x20007FF8 ─ 0x20007FFF   Boot/App 共享区
 *       0x20007FFC            编程请求标志
 *
 *   ★ 共享区之所以能跨复位保留，是因为 RamInit0.S 对 STACK 区间做 0x5A
 *     填充，范围是 [STACK_memory_start, STACK_memory_end]。本工程的
 *     board/yt_linker.icf 必须把 STACK_memory_end 改为 0x20007FF7
 *     （而不是原来单工程布局下的 0x20007FFF），代价是 8 字节栈空间。
 *     Boot 工程的链接脚本须使用完全相同的 STACK_memory_end。
 */
#ifndef BOOT_APP_IF_H
#define BOOT_APP_IF_H

#include <stdint.h>

/*===========================================================================
 *  1. Flash 分区
 *===========================================================================*/
#define FLASH_BASE_ADDR         (0x00000000UL)
#define FLASH_END_ADDR          (0x0003FFFFUL)   /**< 256KB，YTM32B1MC0     */
#define FLASH_SECTOR_SIZE       (0x200UL)        /**< 扇区 512 字节         */
#define FLASH_WRITE_UNIT        (8UL)            /**< 写入单元 8 字节       */

#define BOOT_START_ADDR         (0x00000000UL)
#define BOOT_END_ADDR           (0x00007FFFUL)

#define APP_START_ADDR          (0x00008000UL)
#define APP_END_ADDR            (0x0003FFFFUL)
#define APP_MAX_SIZE            (APP_END_ADDR - APP_START_ADDR + 1UL)

/** App 信息块地址：紧跟 App 向量表之后 */
#define APP_INFO_ADDR           (0x00008400UL)

/*===========================================================================
 *  2. 数据 Flash（仅 Boot 使用，App 不直接访问，列在此处方便对照）
 *===========================================================================*/
#define DFLASH_BASE_ADDR        (0x10001000UL)
#define DFLASH_SECTOR_SIZE      (0x200UL)
#define BOOT_RECORD_ADDR        (DFLASH_BASE_ADDR)

/*===========================================================================
 *  3. Boot / App 共享标志
 *===========================================================================*/
#define BOOT_FLAG_ADDR          (0x20007FFCUL)
#define BOOT_FLAG_PROG_REQUEST  (0x72717374UL)   /**< "rqst" */
#define BOOT_FLAG_NONE          (0x00000000UL)

/*===========================================================================
 *  4. App 信息块
 *
 *  App 侧用 #pragma location 把 g_appInfo 定位到 APP_INFO_ADDR；
 *  Boot 侧直接按该地址读，用于：
 *    - 回答 0x22 的四个标识 DID（流程步骤 7~10 / 29~32）
 *    - 步骤 23 的依赖检查（校验 magic 与 signature）
 *===========================================================================*/
#define APP_INFO_MAGIC          (0x4F464E49UL)       /**< 'I','N','F','O' 小端 */
#define APP_SIGNATURE_TEXT      "CY100V1-CLUSTER "   /**< 恰好 16 字符，须与 Boot 一致 */
#define APP_SIGNATURE_LEN       (16U)

typedef struct {
    uint32_t magic;              /**< APP_INFO_MAGIC                      */
    uint32_t infoVersion;        /**< 结构版本，当前 1                     */
    uint8_t  swVersion[16];      /**< F189 OEM 软件版本号（对外 10 字节） */
    uint8_t  swNumber[16];       /**< F188 OEM 软件号（对外 16 字节）     */
    uint8_t  hwVersion[16];      /**< F191 OEM 硬件版本号（对外 10 字节） */
    uint8_t  partNumber[16];     /**< F187 OEM 零部件号（对外 16 字节）   */
    uint8_t  signature[16];      /**< 项目签名，须等于 APP_SIGNATURE_TEXT */
    uint32_t reserved[6];
} AppInfo_t;                     /* 112 字节，8 的倍数 */

/*===========================================================================
 *  5. 刷写记录（存于数据 Flash，仅 Boot 读写，App 不涉及，列出便于对照）
 *===========================================================================*/
#define BOOT_RECORD_MAGIC       (0x444C4156UL)   /**< 'V','A','L','D' 小端 */
#define FINGERPRINT_LEN         (66U)            /**< F15C 长度 */

typedef struct {
    uint32_t magic;
    uint32_t appLen;
    uint32_t appCrc;
    uint32_t progCount;
    uint8_t  fingerprint[FINGERPRINT_LEN];
    uint8_t  pad[2];
    uint32_t recCrc;
} BootRecord_t;                            /* 88 字节，8 的倍数 */

/*===========================================================================
 *  6. 诊断 CAN ID（Boot 与 App 必须一致）
 *===========================================================================*/
#define UDS_ID_PHYS_REQ         (0x7C6UL)   /**< 诊断仪 → ECU，物理寻址 */
#define UDS_ID_FUNC_REQ         (0x7DFUL)   /**< 诊断仪 → ECU，功能寻址 */
#define UDS_ID_RESP             (0x7CEUL)   /**< ECU → 诊断仪            */

#endif /* BOOT_APP_IF_H */
