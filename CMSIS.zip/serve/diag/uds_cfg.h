/**
 * @file    uds_cfg.h
 * @brief   App 侧 UDS 诊断配置
 *
 * 覆盖 32 步刷写流程中的 App 侧部分：步骤 1~11 与 25~32。
 * 步骤 12~24（安全解锁二级、擦除、传输、校验）在 Bootloader 中执行，
 * 与本文件无关。
 */
#ifndef CLUSTER_UDS_CFG_H
#define CLUSTER_UDS_CFG_H

#include "types.h"
#include "boot_app_if.h"    /* 与 Boot 共用的契约：地址、AppInfo_t、CAN ID */

/*===========================================================================
 *  1. 诊断 CAN ID
 *
 *  UDS_ID_PHYS_REQ / UDS_ID_FUNC_REQ / UDS_ID_RESP 定义在 boot_app_if.h，
 *  Boot 与 App 必须一致，故不在此重复定义。
 *===========================================================================*/

/*===========================================================================
 *  2. 网络层（ISO 15765-2）
 *===========================================================================*/
#define UDS_TP_PADDING      (0xAAU)     /**< 填充字节           */
#define UDS_TP_BS           (0x00U)     /**< 流控 BlockSize     */
#define UDS_TP_STMIN        (0x00U)     /**< 流控 STmin         */

#define UDS_N_BS_MS         (150U)      /**< 发完 FF 等 FC 的超时 */
#define UDS_N_CR_MS         (150U)      /**< 等下一帧 CF 的超时   */

/** App 侧最长响应是 62 F1 88 + 16B = 19 字节，256 留足余量 */
#define UDS_BUF_SIZE        (256U)

/*===========================================================================
 *  3. 应用层时间参数
 *===========================================================================*/
#define UDS_P2_SERVER_MS    (50U)
#define UDS_P2_STAR_MS      (5000U)
#define UDS_S3_SERVER_MS    (5000U)

/** 收到 10 02 后先回 0x78，等这段时间让报文上总线，再软复位 */
#define UDS_JUMP_DELAY_MS   (30U)

/*===========================================================================
 *  4. 安全访问（一级，流程步骤 4~5）
 *
 *  注意：Boot 侧用的是二级子功能 0x11 / 0x12（步骤 12~13），
 *        算法相同但子功能号不同，两者互不影响，各自独立解锁状态。
 *===========================================================================*/
#define UDS_SEC_L1_REQ_SEED (0x01U)
#define UDS_SEC_L1_SEND_KEY (0x02U)
#define UDS_SEC_SEED_LEN    (4U)
#define UDS_SEC_MAX_RETRY   (3U)
#define UDS_SEC_LOCK_MS     (10000U)

/*===========================================================================
 *  5. 例程标识符
 *===========================================================================*/
#define UDS_RID_PRE_PROG    (0xDFFDU)   /**< 步骤 6：预编程条件检查 */

/*===========================================================================
 *  6. 数据标识符与长度
 *
 *  长度取自流程表的多帧首帧 PCI：
 *    步骤 7  10 0D 62 F1 89 → 0x0D-3 = 10 字节
 *    步骤 8  10 13 62 F1 88 → 0x13-3 = 16 字节
 *    步骤 9  10 0D 62 F1 91 → 0x0D-3 = 10 字节
 *    步骤 10 10 13 62 F1 87 → 0x13-3 = 16 字节
 *===========================================================================*/
#define UDS_DID_OEM_SW_VER      (0xF189U)
#define UDS_DID_OEM_SW_NUM      (0xF188U)
#define UDS_DID_OEM_HW_VER      (0xF191U)
#define UDS_DID_OEM_PART_NUM    (0xF187U)

#define UDS_LEN_OEM_SW_VER      (10U)
#define UDS_LEN_OEM_SW_NUM      (16U)
#define UDS_LEN_OEM_HW_VER      (10U)
#define UDS_LEN_OEM_PART_NUM    (16U)

/*===========================================================================
 *  7. 进入 Bootloader
 *
 *  BOOT_FLAG_ADDR / BOOT_FLAG_PROG_REQUEST 定义在 boot_app_if.h。
 *  下面两个别名保持代码可读性。
 *===========================================================================*/
#define UDS_BOOT_FLAG_ADDR      BOOT_FLAG_ADDR
#define UDS_BOOT_FLAG_REQUEST   BOOT_FLAG_PROG_REQUEST

/*===========================================================================
 *  8. 预编程条件门限（步骤 6：31 01 DF FD）
 *
 *  电压区间与 cfg_power.h / voltage.h 的正常工作区间（9~18V）一致；
 *  车速门限 0 表示"必须静止"（跨越星车型仪表当前策略）。
 *===========================================================================*/
#define UDS_PROG_VOLT_MIN_MV    (9000U)
#define UDS_PROG_VOLT_MAX_MV    (18000U)
#define UDS_PROG_SPEED_MAX_KMH  (0U)

#endif /* CLUSTER_UDS_CFG_H */
